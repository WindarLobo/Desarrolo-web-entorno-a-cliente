$(document).ready(function () {
    let clasificacion = JSON.parse(localStorage.getItem('clasificacion'));
    if(!clasificacion){
        let clasificacion_por_defecto = [
            { nombre: "Jugador1", dni: "12345678A", puntuacion: 100 },
            { nombre: "Jugador2", dni: "87654321B", puntuacion: 90 },
        ];
        clasificacion_por_defecto = localStorage.setItem('clasificacion', JSON.stringify(clasificacion_por_defecto));
        clasificacion = clasificacion_por_defecto;
    }
    
    let tabla = $('#tabla-clasificacion');
    clasificacion.forEach(function (jugador) {
        tabla.append(`<br>${jugador.nombre} - ${jugador.dni} - ${jugador.puntuacion}`);
    });

    $('#btn-jugar').click(function (e) {
        e.preventDefault();

        let campoNombre = validaCampoNombre();
        let campoDNI = validaCampoDNI();

        if (campoNombre && campoDNI) {
            $('#errores').hide();

            inicioJuego();
        }
    });

    function validaCampoNombre() {
        let nombre = $('#nombre').val().trim();
    
        if (nombre.includes(' ') || nombre === '') {
            $('#errores').text('El valor del campo nombre no puede tener espacios ni estar vacío').show();
            return false;
        }
    
        return true;
    }
    
    function validaCampoDNI() {
        let dni = $('#dni').val();
        let expresion_regular_dni = /^\d{8}[a-zA-Z]$/;
    
        if (expresion_regular_dni.test(dni) === false) {
            $('#errores').text('El valor del campo DNI está mal escrito').show();
            return false;
        }
    
        return true;
    }

    function inicioJuego() {
        $('#temporizador').html(`<span id="minutos">01</span>:<span id="segundos">30</span>`);

        let segundos = parseInt($('#segundos').text());
        let minutos = parseInt($('#minutos').text());

        let temporizador = setInterval(function() {
            if (segundos > 0) {
                segundos--;
            } else {
                if (minutos > 0) {
                    minutos--;
                    segundos = 59;
                } else {
                    clearInterval(temporizador);
                    finJuego();
                    return;
                }
            }

            
            $('#segundos').text(segundos < 10 ? '0' + segundos : segundos);
            $('#minutos').text(minutos < 10 ? '0' + minutos : minutos);
        }, 100);
        getPuntos();
    }

    
        function getPuntos() {
            let puntuacionTotal = 0;
    
            $('.cuadro').each(function() {
                $(this).data('puntuacion', 0);
            });
    
            $('.cuadro').on('click', function() {
                let puntuacionCuadro = $(this).data('puntuacion') + 1;
                $(this).data('puntuacion', puntuacionCuadro);
                $(this).text(puntuacionCuadro);
                puntuacionTotal = calcularPuntuacionTotal();
                localStorage.setItem('puntuacionTotal', puntuacionTotal); // Guardar la puntuación total en localStorage
            });
    
            function calcularPuntuacionTotal() {
                let total = 0;
                $('.cuadro').each(function() {
                    total += parseInt($(this).data('puntuacion')) || 0;
                });
                return total;
            }
        }
    
        // Función para finalizar el juego
        function finJuego() {
            clearInterval(temporizador);
            $('.cuadro').off('click');
        }

        function ordenaClasificacion(nombreJugador, dniJugador, puntuacionJugador) {
            let clasificacion = JSON.parse(localStorage.getItem('clasificacion')) || [];
        
            let jugadorExistenteIndex = clasificacion.findIndex(jugador => jugador.dni === dniJugador);
        
            if (jugadorExistenteIndex !== -1) {
                if (puntuacionJugador > clasificacion[jugadorExistenteIndex].puntuacion) {
                    clasificacion[jugadorExistenteIndex].puntuacion = puntuacionJugador;
                }
            } else {
                clasificacion.push({ nombre: nombreJugador, dni: dniJugador, puntuacion: puntuacionJugador });
            }
        
            clasificacion.sort((a, b) => b.puntuacion - a.puntuacion);
        
            clasificacion = clasificacion.slice(0, 10);
        
            localStorage.setItem('clasificacion', JSON.stringify(clasificacion));
        
            let tablaClasificacion = $('#tabla-clasificacion');
            tablaClasificacion.empty();
        
            clasificacion.forEach((jugador, index) => {
                tablaClasificacion.append(`<tr><td>${index + 1}</td><td>${jugador.nombre}</td><td>${jugador.dni}</td><td>${jugador.puntuacion}</td></tr>`);
            });
        }
        
    
        // Función para ordenar la clasificación al finalizar el juego
        $('#btn-finalizar').on('click', function() {
            // Obtener los valores de los campos del formulario
            let nombreJugador = $('#nombre').val();
            let dniJugador = $('#dni').val();
            let puntuacionJugador = localStorage.getItem('puntuacionTotal');
    
            // Verificar si la puntuación del jugador es válida
            if (!isNaN(puntuacionJugador) && puntuacionJugador !== null) {
                // Llamar a la función ordenaClasificacion para actualizar la clasificación con los nuevos datos del jugador
                ordenaClasificacion(nombreJugador, dniJugador, parseInt(puntuacionJugador));
            } else {
                console.error('La puntuación del jugador no es válida.');
            }
    
            // Llamar a la función inicioAplicacion si es necesario
            inicioAplicacion();
        });
});
